
public enum Mode {
	BMI, BFP, BMR, CI
}
